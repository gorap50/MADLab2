package com.example.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun disply(v:View)
    {
        val txt:TextView=findViewById(R.id.textView2)
        txt.text=txt.text.toString()+ (v as TextView).text.toString()
    }
    fun clear(v:View){
        val txt:TextView=findViewById(R.id.textView2)
        txt.text = "";
    }
    fun eval(v:View){
        val txt:TextView=findViewById(R.id.textView2)
        var exp: String = txt.text.toString()
        var num: String = ""
        var symbol: Char = '+'
        var result: Int = 0

        for(i in exp)
        {
            if(i in '0'..'9')
                num += i
            else
            {
                if(symbol == '+')
                    result += Integer.parseInt(num)
                else if(symbol == '-')
                    result -= Integer.parseInt(num)
                else if(symbol == '*')
                    result *= Integer.parseInt(num)
                else if(symbol == '/')
                    result /= Integer.parseInt(num)

                num=""
                symbol = i
            }
        }

        //To calculate the divide by 4 ( result/4 ) in this case
        if(symbol == '+')
            result += Integer.parseInt(num)
        else if(symbol == '-')
            result -= Integer.parseInt(num)
        else if(symbol == '*')
            result *= Integer.parseInt(num)
        else if(symbol == '/')
            result /= Integer.parseInt(num)

        txt.text = ""+result;
    }

}