package com.example.cofeeshop

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
var quantity=0
    fun incrmnt(view: View)
    {
        quantity++
        val tv : TextView = findViewById(R.id.txtqnty)
        tv.text=""+quantity
    }

    fun dcrmnt(view: View)
    {
        if(quantity<1)
        {
            Toast.makeText(this, "Quantity should be>0", Toast.LENGTH_SHORT).show()
        }
        else
        {
            quantity--
        }

        val tv : TextView = findViewById(R.id.txtqnty)
        tv.text=""+quantity
    }

    fun order(view: View)
    {
        val crm:CheckBox=findViewById(R.id.checkBoxCream)
        val chklt:CheckBox=findViewById(R.id.checkBoxchoco)
        val rcept : TextView = findViewById(R.id.rcpt)

    var price=0.0;
        price=4.0*quantity;
        if(crm.isChecked)
        {
            price=price+(quantity*0.5)
            rcept.text="Add Whiped Cream? Yes \n"
        }
        else
        {
            rcept.text="Add Whiped Cream? No \n"
        }
        if(chklt.isChecked)
        {
            price=price+1.0
            rcept.setText(rcept.text.toString()+"Add Chocklate? Yes \n")
        }
        else
        {
            rcept.text=rcept.text.toString()+"Add Chocklate? No \n"
        }

        rcept.text=rcept.text.toString()+"Quantity: "+quantity+"\n \n"
        rcept.text=rcept.text.toString()+"Price: "+"$"+price+"\n"
        rcept.text=rcept.text.toString()+"THANKYOU!!!"

    }
}