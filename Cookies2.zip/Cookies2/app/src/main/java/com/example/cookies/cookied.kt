package com.example.cookies

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class cookied : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cookied)
    }
    fun Finish(view: View)
    {
        finish()
    }
}