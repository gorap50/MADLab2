package com.example.lab2task1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.d("OnCreate","Application Created");
    }

    override fun onStart() {
        super.onStart()
        Log.d("onStart","Application Started")
    }

    override fun onResume() {
        super.onResume()
        Log.d("onResume","Application Resumed")
    }

    override fun onPause() {
        super.onPause()
        Log.d("onPause","Application Paused")
    }

    override fun onStop() {
        super.onStop()
        Log.d("onStop","Application Stopped")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("OnRestart","Application Restarted")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("onDestroy","Application Destroyed")
    }

}